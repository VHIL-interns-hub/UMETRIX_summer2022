package android.support.v4.view;

import android.view.PointerIcon;
import android.view.View;

class ViewCompatApi24
{
  ViewCompatApi24() {}
  
  public static void setPointerIcon(View paramView, Object paramObject)
  {
    paramView.setPointerIcon((PointerIcon)paramObject);
  }
}
