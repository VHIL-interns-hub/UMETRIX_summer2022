package android.support.v4.media;

public class TransportStateListener
{
  public TransportStateListener() {}
  
  public void onPlayingChanged(TransportController paramTransportController) {}
  
  public void onTransportControlsChanged(TransportController paramTransportController) {}
}
