package android.support.v4.text;

public abstract interface TextDirectionHeuristicCompat
{
  public abstract boolean isRtl(CharSequence paramCharSequence, int paramInt1, int paramInt2);
  
  public abstract boolean isRtl(char[] paramArrayOfChar, int paramInt1, int paramInt2);
}
