package android.support.v4.app;

abstract interface NotificationBuilderWithActions
{
  public abstract void addAction(NotificationCompatBase.Action paramAction);
}
